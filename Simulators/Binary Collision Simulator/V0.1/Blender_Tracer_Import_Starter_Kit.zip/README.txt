
==============================
DWARF Binary Collision - Blender Starter Kit
==============================

📂 Contents:
- import_tracer_curves_to_blender.py : Blender script to import tracer .csv paths

📦 How to Use:
1. Run the Python simulation script provided earlier (dwarf_binary_collision_simulation.py)
   This will generate files: tracer_0.csv, tracer_1.csv, ..., tracer_499.csv

2. Open Blender.
   Navigate to the Scripting tab.

3. Place the .csv files and 'import_tracer_curves_to_blender.py' in the same folder.

4. In Blender's scripting tab, open and run 'import_tracer_curves_to_blender.py'.
   It will automatically create 3D path curves for each tracer.

🧙‍♂️ Tips:
- Use Curve modifiers to stylize each path with thickness, glow, or volumetric trails.
- You can parent spheres or emitters to the curves to visualize energy flow.

🪐 Enjoy your journey into relativistic chaos!
